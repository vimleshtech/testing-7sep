package day01;

import java.util.Scanner;

public class SwitchExample {

	public static void main(String[] args) {
		
		int day;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data ");
		day = sc.nextInt();
		
		switch (day) {
			case 1:
				System.out.println("monday ");
				break;//terminate the condition 
				
			case 2:
				System.out.println("tuesday");
				break;
			case 3:
				System.out.println("wednesday");
				break;
			case 4:
				System.out.println("Thursday");
				break;
			default:
				System.out.println("other day ...");
				break;
		}
		
		
	}

}

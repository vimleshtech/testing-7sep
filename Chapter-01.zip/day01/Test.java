package day01;

import example.*;
import java.util.*;

//F11 to execute the code 
public class Test 
{

	public static void main(String[] arg) 
	{
		
		System.out.println("hi this is test code");
		
		int a,b,c;
		a =55;
		b =55;
		c =a+b;
		
		System.out.println("sum of two numebrs "+c);
		
		//input//Scanner is inbuilt class to read data from user 
		Scanner sc = new Scanner(System.in);
		//sc is an object, new is keyoword which allocate the memory
		
		System.out.println("enter num ");
		a = sc.nextInt(); //read int valu
		
		System.out.println("enter num ");
		b = sc.nextInt(); //read int value 
		
		
		System.out.println("enter name ");
		String name = sc.next();//read string
		
		
		c =a+b;		
		System.out.println("sum of two numbers "+c);
		System.out.println("name is "+name);
		
		
	}

}
